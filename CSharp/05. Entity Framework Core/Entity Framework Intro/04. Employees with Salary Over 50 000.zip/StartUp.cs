﻿using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var context = new SoftUniContext();
            //Console.WriteLine(GetEmployeesFullInformation(context));
            Console.WriteLine(GetEmployeesWithSalaryOver50000(context));
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            //Your task is to extract all employees with salary over 50000.Return their first names and salaries in format “{ firstName}
            //- { salary}”.Salary must be rounded to 2 symbols, after the decimal separator. Sort them alphabetically by first name.


            StringBuilder result = new StringBuilder();

            var employees = context.Employees
                .OrderBy(x => x.FirstName)
                .Select(e => new Employee
                {
                    FirstName = e.FirstName,
                    Salary = e.Salary
                })
                .Where(e => e.Salary > 50000)
                .ToList();

            foreach (var employee in employees)
            {
                result.AppendLine($"{employee.FirstName} - {employee.Salary:f2}");
            }

            return result.ToString();
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                .OrderBy(e => e.EmployeeId)
                .Select(e =>new Employee
                {
                    FirstName=e.FirstName,
                    LastName=e.LastName,
                    MiddleName=e.MiddleName,
                    JobTitle=e.JobTitle,
                    Salary=e.Salary
                })
                .ToList();

            foreach (var item in employees)
            {
                sb.AppendLine(item.FirstName + " " + item.LastName + " " + item.MiddleName + " " + item.JobTitle + " " + $"{item.Salary:f2}");
            }

            return sb.ToString();
        }         
    }
}
