﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vehicles.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
