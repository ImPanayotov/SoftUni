﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Models.Foods.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
