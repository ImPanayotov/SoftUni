﻿using _04.WildFarm.Core;
using System;

namespace _04.WildFarm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
