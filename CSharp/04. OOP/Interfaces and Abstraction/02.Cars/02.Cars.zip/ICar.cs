﻿namespace Cars
{
    internal interface ICar
    {
        

        void Start();

        void Stop();
    }
}