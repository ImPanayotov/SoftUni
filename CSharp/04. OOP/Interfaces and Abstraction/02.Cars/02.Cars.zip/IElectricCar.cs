﻿
namespace Cars
{
    interface IElectricCar
    {
    }
}
