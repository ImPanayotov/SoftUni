﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
