﻿using _04.BorderControl.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _04.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Engine engine = new Engine();

            engine.Run();

        }
    }
}
