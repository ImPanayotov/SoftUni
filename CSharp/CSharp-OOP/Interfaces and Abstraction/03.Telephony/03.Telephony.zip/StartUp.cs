﻿using System;
using System.Linq;

namespace _03.Telephony
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }

        
    }
}
