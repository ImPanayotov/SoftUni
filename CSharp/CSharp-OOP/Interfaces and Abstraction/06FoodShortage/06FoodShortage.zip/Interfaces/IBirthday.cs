﻿

namespace _06FoodShortage.Interfaces
{
    public interface IBirthday
    {
        public string Birthday { get; }

    }
}
