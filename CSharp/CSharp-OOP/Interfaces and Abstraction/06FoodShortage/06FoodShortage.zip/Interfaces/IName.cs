﻿namespace _06FoodShortage.Core
{
    public interface IName
    {
        public string Name { get; }

    }
}