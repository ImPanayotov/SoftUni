﻿
namespace _06FoodShortage.Interfaces
{
    public interface IId
    {
        public string Id { get; }

    }
}
